﻿namespace Eco_life.Models
{
    public class Cadastros
    {
        public int Id { get; set; }

        public string nome { get; set; }
        public string email { get; set; }

        public string senha { get; set; }
        public int cpf { get; set; }

    }
}
