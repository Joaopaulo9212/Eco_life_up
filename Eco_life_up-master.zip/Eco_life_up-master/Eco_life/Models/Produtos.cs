namespace Eco_life.Models
{
    public class Produto
    {
        public int Id { get; set; }

        public string nome { get; set; }
        public double preco { get; set; }

        public int estoque { get; set; }

    }
}
